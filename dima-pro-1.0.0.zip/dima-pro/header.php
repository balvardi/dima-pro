<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>

    <!-- SEO Meta Tags -->
    <meta name="description" content="<?php echo esc_attr(get_bloginfo('description')); ?>">
    <meta name="keywords" content="<?php echo esc_attr('وردپرس, بوت‌استراپ, قالب, سئو'); ?>">
    <meta name="author" content="<?php echo esc_attr(get_bloginfo('name')); ?>">

    <!-- Open Graph Tags -->
    <meta property="og:title" content="<?php echo esc_attr(get_option('dima_pro_og_title', get_bloginfo('name'))); ?>">
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?php echo esc_url(home_url('/')); ?>">
    <meta property="og:description" content="<?php echo esc_attr(get_option('dima_pro_og_description', get_bloginfo('description'))); ?>">
    <meta property="og:image" content="<?php echo esc_url(get_option('dima_pro_og_image', get_template_directory_uri() . '/assets/images/og-image.jpg')); ?>">

    <!-- Twitter Card Tags -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?php echo esc_attr(get_option('dima_pro_og_title', get_bloginfo('name'))); ?>">
    <meta name="twitter:description" content="<?php echo esc_attr(get_option('dima_pro_og_description', get_bloginfo('description'))); ?>">
    <meta name="twitter:image" content="<?php echo esc_url(get_option('dima_pro_og_image', get_template_directory_uri() . '/assets/images/og-image.jpg')); ?>">
</head>
<body <?php body_class(); ?>>
    <header class="bg-primary text-white py-4">
        <div class="container">
            <h1><?php echo esc_html(get_bloginfo('name')); ?></h1>
            <p><?php echo esc_html(get_bloginfo('description')); ?></p>
        </div>
    </header>

    <!-- Navigation Menu -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="<?php echo esc_url(home_url('/')); ?>"><?php echo esc_html(get_bloginfo('name')); ?></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <?php
                wp_nav_menu(array(
                    'theme_location' => 'primary',
                    'menu_class'     => 'navbar-nav ms-auto', // کلاس بوت‌استراپ برای منو
                    'container'      => false,
                    'fallback_cb'    => false,
                ));
                ?>
            </div>
        </div>
    </nav>