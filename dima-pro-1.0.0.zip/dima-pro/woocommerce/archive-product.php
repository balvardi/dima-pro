<?php
/**
 * The main template file for displaying shop page.
 */

get_header(); ?>

<div class="container">
    <div class="row">
        <div class="col-md-3">
            <?php dynamic_sidebar('shop-sidebar'); ?>
        </div>
        <div class="col-md-9">
            <?php if (have_posts()) : ?>
                <div class="row">
                    <?php while (have_posts()) : the_post(); ?>
                        <div class="col-md-4 mb-4">
                            <div class="card">
                                <?php the_post_thumbnail('medium', array('class' => 'card-img-top')); ?>
                                <div class="card-body">
                                    <h5 class="card-title"><?php the_title(); ?></h5>
                                    <p class="card-text"><?php echo wc_price(get_post_meta(get_the_ID(), '_price', true)); ?></p>
                                    <a href="<?php the_permalink(); ?>" class="btn btn-primary">View Product</a>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php else : ?>
                <p>No products found.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php get_footer();