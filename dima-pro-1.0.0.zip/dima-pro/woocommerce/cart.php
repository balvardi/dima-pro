<?php
/**
 * The template for displaying the cart page.
 */

get_header(); ?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <?php the_content(); ?>
        </div>
    </div>
</div>

<?php get_footer();