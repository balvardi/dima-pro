<?php
/**
 * The template for displaying single product pages.
 */

get_header(); ?>

<div class="container">
    <div class="row">
        <div class="col-md-8">
            <?php while (have_posts()) : the_post(); ?>
                <div class="card mb-4">
                    <?php the_post_thumbnail('large', array('class' => 'card-img-top')); ?>
                    <div class="card-body">
                        <h2 class="card-title"><?php the_title(); ?></h2>
                        <p class="card-text"><?php echo wc_price(get_post_meta(get_the_ID(), '_price', true)); ?></p>
                        <div><?php the_content(); ?></div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
        <div class="col-md-4">
            <?php dynamic_sidebar('shop-sidebar'); ?>
        </div>
    </div>
</div>

<?php get_footer();