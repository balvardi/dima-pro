<?php
// Load Bootstrap CSS and JS
function dima_pro_enqueue_styles() {
    wp_enqueue_style('bootstrap-css', get_template_directory_uri() . '/assets/css/bootstrap.min.css');
    wp_enqueue_script('bootstrap-js', get_template_directory_uri() . '/assets/js/bootstrap.bundle.min.js', array('jquery'), null, true);
}
add_action('wp_enqueue_scripts', 'dima_pro_enqueue_styles');

// Register Widget Positions from JSON
function dima_pro_register_sidebars() {
    $widget_positions = json_decode(file_get_contents(get_template_directory() . '/assets/json/widget-positions.json'), true);

    if ($widget_positions && is_array($widget_positions)) {
        foreach ($widget_positions as $position) {
            register_sidebar(array(
                'name'          => sanitize_text_field($position['name']), // Sanitize name
                'id'            => sanitize_title($position['id']), // Sanitize ID
                'description'   => sanitize_text_field($position['description']), // Sanitize description
                'before_widget' => '<div id="%1$s" class="widget %2$s">',
                'after_widget'  => '</div>',
                'before_title'  => '<h3 class="widget-title">',
                'after_title'   => '</h3>',
            ));
        }
    }
}
add_action('widgets_init', 'dima_pro_register_sidebars');

// Add WooCommerce Support
function dima_pro_woocommerce_support() {
    add_theme_support('woocommerce');
    add_theme_support('wc-product-gallery-zoom');
    add_theme_support('wc-product-gallery-lightbox');
    add_theme_support('wc-product-gallery-slider');
}
add_action('after_setup_theme', 'dima_pro_woocommerce_support');

// Add Elementor Support
function dima_pro_elementor_support() {
    add_theme_support('align-wide');
}
add_action('after_setup_theme', 'dima_pro_elementor_support');

// Add Title Tag Support
function dima_pro_setup() {
    add_theme_support('title-tag'); // افزودن پشتیبانی برای تگ <title>
}
add_action('after_setup_theme', 'dima_pro_setup');

// Include Theme Options
require_once get_template_directory() . '/inc/theme-options.php';

// Security: Disable File Editing in WordPress Admin
define('DISALLOW_FILE_EDIT', true);

// Security: Remove WordPress Version Meta Tag
function dima_pro_remove_wp_version() {
    return '';
}
add_filter('the_generator', 'dima_pro_remove_wp_version');

// Security: Disable XML-RPC (Optional)
add_filter('xmlrpc_enabled', '__return_false');

// Security: Disable REST API for non-authenticated users
function dima_pro_disable_rest_api($access) {
    if (!is_user_logged_in()) {
        return new WP_Error('rest_disabled', __('REST API is disabled for non-authenticated users.'), array('status' => 403));
    }
    return $access;
}
add_filter('rest_authentication_errors', 'dima_pro_disable_rest_api');
// Register Navigation Menu
function dima_pro_register_menus() {
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'dima-pro'), // منوی اصلی
    ));
}
add_action('after_setup_theme', 'dima_pro_register_menus');