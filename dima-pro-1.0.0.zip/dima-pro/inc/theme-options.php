<?php
function dima_pro_options_page() {
    add_menu_page(
        'Dima Pro Options',
        'Dima Pro Options',
        'manage_options',
        'dima-pro-options',
        'dima_pro_options_page_html',
        'dashicons-admin-generic',
        100
    );
}
add_action('admin_menu', 'dima_pro_options_page');

function dima_pro_options_page_html() {
    ?>
    <div class="wrap">
        <h1>Dima Pro Options</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('dima_pro_options_group');
            do_settings_sections('dima-pro-options');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

function dima_pro_register_settings() {
    register_setting('dima_pro_options_group', 'dima_pro_og_title', 'sanitize_text_field');
    register_setting('dima_pro_options_group', 'dima_pro_og_description', 'sanitize_textarea_field');
    register_setting('dima_pro_options_group', 'dima_pro_og_image', 'esc_url_raw');

    add_settings_section(
        'dima_pro_main_section',
        'Customize Open Graph Tags',
        null,
        'dima-pro-options'
    );

    add_settings_field(
        'dima_pro_og_title',
        'OG Title',
        'dima_pro_og_title_callback',
        'dima-pro-options',
        'dima_pro_main_section'
    );

    add_settings_field(
        'dima_pro_og_description',
        'OG Description',
        'dima_pro_og_description_callback',
        'dima-pro-options',
        'dima_pro_main_section'
    );

    add_settings_field(
        'dima_pro_og_image',
        'OG Image URL',
        'dima_pro_og_image_callback',
        'dima-pro-options',
        'dima_pro_main_section'
    );
}
add_action('admin_init', 'dima_pro_register_settings');

function dima_pro_og_title_callback() {
    $og_title = get_option('dima_pro_og_title', get_bloginfo('name'));
    echo '<input type="text" name="dima_pro_og_title" value="' . esc_attr($og_title) . '" class="regular-text">';
}

function dima_pro_og_description_callback() {
    $og_description = get_option('dima_pro_og_description', get_bloginfo('description'));
    echo '<textarea name="dima_pro_og_description" rows="5" class="large-text">' . esc_textarea($og_description) . '</textarea>';
}

function dima_pro_og_image_callback() {
    $og_image = get_option('dima_pro_og_image', get_template_directory_uri() . '/assets/images/og-image.jpg');
    echo '<input type="url" name="dima_pro_og_image" value="' . esc_url($og_image) . '" class="regular-text">';
}